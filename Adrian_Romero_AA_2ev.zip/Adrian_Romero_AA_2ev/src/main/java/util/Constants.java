package util;

public class Constants {


    public static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";


    public static final String ORACLE_URL = "jdbc:oracle:thin@localhost:1521/xe";

    public static final String USERNAME = "ALUMNO";
    public static final String PASSWORD = "1234";
}
